ant.copy(file: "${pluginBasedir}/src/samples/ZapSecurityTestsConfig.groovy",
    todir: "${basedir}/grails-app/conf")
